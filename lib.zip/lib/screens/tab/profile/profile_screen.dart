import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:todo_app/screens/routes.dart';
import 'package:todo_app/utils/app/app.dart';
import 'package:todo_app/utils/appcolors/app_colors.dart';
import 'package:zoom_tap_animation/zoom_tap_animation.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: 50.h),
            Text(
              "Profile",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20.w,
              ),
            ),
            SizedBox(height: 25.h),
            CircleAvatar(
              radius: 43.w,
              child: ClipOval(
                child: Image.asset("assets/images/ps.png", width: 85.w),
              ),
            ),
            SizedBox(height: 25.h),
            Text(
              "Martha Hays",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20.w,
              ),
            ),
            SizedBox(height: 20.h),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 24.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8.r),
                            color: AppColors.c363636,
                          ),
                          padding: EdgeInsets.symmetric(vertical: 17.h),
                          child: Center(
                            child: Text(
                              "10 Task Level",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14.w,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 20.w),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8.r),
                            color: AppColors.c363636,
                          ),
                          padding: EdgeInsets.symmetric(vertical: 17.h),
                          child: Center(
                            child: Text(
                              "10 Task done",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14.w,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 32.h),
                  Text(
                    "Settings",
                    style: TextStyle(
                      color: AppColors.c363636,
                      fontSize: 14.w,
                    ),
                  ),
                  SizedBox(height: 16.h),
                  ZoomTapAnimation(
                    onTap: () {
                      Navigator.pushNamed(context, RouteNames.addCategory);
                      },
                    child: SizedBox(
                      child: Row(
                        children: [
                          Icon(
                            Icons.settings,
                            color: Colors.white,
                            weight: 24.w,
                          ),
                          SizedBox(width: 10.w),
                          Text(
                            "App Settings",
                            style: TextStyle(
                              color: AppColors.white,
                              fontSize: 16.w,
                            ),
                          ),
                          const Spacer(),
                          Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.white,
                            weight: 24.w,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
