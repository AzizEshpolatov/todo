import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:todo_app/utils/appcolors/app_colors.dart';
import 'package:zoom_tap_animation/zoom_tap_animation.dart';
import '../../../data_local/local/local_database.dart';
import '../../../data_local/models/category_model.dart';
import '../../../data_local/models/task/tack_model.dart';
import '../../../utils/app/app.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, this.stream});

  final Stream? stream;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  TaskModel taskModel = TaskModel.initialValue;
  List<TaskModel> tasks = [];
  int activeIndex = 0;

  _init() async {
    tasks = await LocalDatabase.getAllTasks();
    // setState(() {});
  }

  _searchQuery(String q) async {
    tasks = await LocalDatabase.searchTasks(q);
    setState(() {});
  }

  DateTime? dateTime;
  TimeOfDay? timeOfDay;

  @override
  void initState() {
    if (widget.stream != null) {
      widget.stream!.listen((event) {
        _init();
      });
    }
    super.initState();
  }

  bool showValue = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 24.w),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 57.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Material(
                    color: Colors.transparent,
                    child: InkWell(
                      splashColor: Colors.white30,
                      borderRadius: BorderRadius.circular(40.r),
                      onTap: () {},
                      child: Container(
                        width: 42.h,
                        height: 42.h,
                        color: Colors.transparent,
                        child: Center(
                          child: SvgPicture.asset(
                            AppNeseserry.outline,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Text(
                    "Index",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20.sp,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  CircleAvatar(
                    radius: 21.r,
                    child: Image.asset(AppNeseserry.person1),
                  ),
                ],
              ),
              tasks.isEmpty
                  ? Align(
                      alignment: Alignment.center,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          SizedBox(height: 75.h),
                          SizedBox(
                            height: 270.h,
                            child: Image.asset(AppNeseserry.homeImg),
                          ),
                          SizedBox(height: 10.h),
                          Text(
                            "What do you want to do today?",
                            style: TextStyle(
                              fontWeight: FontWeight.w400,
                              fontSize: 20.sp,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(height: 10.h),
                          Text(
                            "Tap + to add your tasks",
                            style: TextStyle(
                              fontWeight: FontWeight.w400,
                              fontSize: 16.sp,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    )
                  : Column(
                      children: [
                        SizedBox(height: 10.h),
                        TextField(
                          onChanged: _searchQuery,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16.r),
                            ),
                            fillColor: Colors.white,
                            filled: true,
                            prefixIcon: const Icon(Icons.search),
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 16.w, vertical: 8.h),
                          ),
                        ),
                        SizedBox(height: 10.h),
                        ...List.generate(
                          tasks.length,
                          (index) {
                            activeIndex = (index);
                            return Container(
                              width: MediaQuery.of(context).size.width - 20,
                              margin: EdgeInsets.symmetric(vertical: 5.h),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 10.w, vertical: 10.h),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(16.r),
                                color: AppColors.c363636,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 10.w),
                                    child: Row(
                                      children: [
                                        SizedBox(
                                          width: 160.w,
                                          child: Text(
                                            tasks[index].title,
                                            style: TextStyle(
                                              fontSize: 16.sp,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                        const Spacer(),
                                        ZoomTapAnimation(
                                          onTap: () async {},
                                          child: const Icon(Icons.edit_calendar,
                                              color: Colors.white),
                                        ),
                                        SizedBox(width: 10.w),
                                        ZoomTapAnimation(
                                          onTap: () async {
                                            await LocalDatabase.deleteTask(
                                              tasks[index].id!,
                                            );
                                            _init();
                                            setState(() {});
                                          },
                                          child: const Icon(
                                            Icons.delete,
                                            color: Colors.red,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Checkbox(
                                        checkColor: Colors.white,
                                        activeColor: Colors.red,
                                        value: tasks[index].isSelected,
                                        side:
                                            MaterialStateBorderSide.resolveWith(
                                          (states) => const BorderSide(
                                            width: 1.0,
                                            color: Colors.white,
                                          ),
                                        ),
                                        onChanged: (value) {
                                          setState(() {
                                            tasks[index].isSelected = value!;
                                          });
                                        },
                                      ),
                                      SizedBox(width: 10.w),
                                      Text(
                                        (tasks[index]
                                            .deadline
                                            .toString()
                                            .substring(0, 10)),
                                        style: TextStyle(
                                          fontSize: 14.sp,
                                          color: const Color(0xFFAFAFAF),
                                        ),
                                      ),
                                      const Spacer(),
                                      Container(
                                        margin:
                                            EdgeInsets.symmetric(vertical: 5.h),
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 10.w),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(4.r),
                                          color:
                                              getColor(tasks[index].category),
                                        ),
                                        child: Row(
                                          children: [
                                            SvgPicture.asset(
                                              getIcon(tasks[index].category),
                                              height: 30.h,
                                            ),
                                            SizedBox(width: 5.w),
                                            Text(
                                              tasks[index].category,
                                              style: TextStyle(
                                                fontSize: 14.sp,
                                                color: Colors.black,
                                              ),
                                            ),
                                            SizedBox(width: 3.w),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ],
                    ),
            ],
          ),
        ),
      ),
    );
  }
}

Color getColor(String text) {
  for (int i = 0; i < categoryAdd.length; i++) {
    if (text == categoryAdd[i].text) {
      return categoryAdd[i].color;
    }
  }
  return Colors.transparent;
}

dynamic getIcon(String text) {
  for (int i = 0; i < categoryAdd.length; i++) {
    if (text == categoryAdd[i].text) {
      return categoryAdd[i].iconLoc;
    }
  }
  return AppNeseserry.add;
}

class DataCategory {
  final String text;
  final Color color;
  final String iconLoc;

  DataCategory({
    required this.text,
    required this.color,
    required this.iconLoc,
  });
}

List<CategoryModel> categoryAdd = [
  CategoryModel(
    iconLoc: AppNeseserry.food,
    text: "Grocery",
    color: const Color(0xFFCC4173),
  ),
  CategoryModel(
    iconLoc: "assets/icons/sumka.svg",
    text: "Work",
    color: const Color(0xFFCCFF80),
  ),
  CategoryModel(
    iconLoc: AppNeseserry.sport,
    text: "Sport",
    color: const Color(0xFFA31D00),
  ),
  CategoryModel(
    iconLoc: AppNeseserry.share,
    text: "Design",
    color: const Color(0xFF80FFFF),
  ),
  CategoryModel(
    iconLoc: AppNeseserry.student,
    text: "University",
    color: const Color(0xFF809CFF),
  ),
  CategoryModel(
    iconLoc: AppNeseserry.karnay,
    text: "Social",
    color: const Color(0xFFFF80EB),
  ),
  CategoryModel(
    iconLoc: AppNeseserry.music,
    text: "Music",
    color: const Color(0xFFFC80FF),
  ),
  CategoryModel(
    iconLoc: AppNeseserry.yurak,
    text: "Health",
    color: const Color(0xFF80FFA3),
  ),
  CategoryModel(
    iconLoc: AppNeseserry.kamera,
    text: "Movie",
    color: const Color(0xFF80D1FF),
  ),
  CategoryModel(
    iconLoc: AppNeseserry.home,
    text: "Movie",
    color: const Color(0xFFFF8080),
  ),
  CategoryModel(
    iconLoc: AppNeseserry.addCategory,
    text: "Add",
    color: const Color(0xFFFF8080),
  ),
];
