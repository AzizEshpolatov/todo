class CategoryModelConstants {
  static const String tableName = "categories";
  static const String color = "color";
  static const String name = "name";
  static const String iconPath = "icon_path";
  static const String id = "_id";
}