import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';

class StorageRepository {
  StorageRepository._();

  static StorageRepository instance = StorageRepository._();
  static SharedPreferences? _preference;

  factory StorageRepository() => instance;

  static Future<void> _init() async {
    _preference = await SharedPreferences.getInstance();
  }

  static Future<void> setInt({
    required String key,
    required int values,
  }) async {
    if (_preference != null) {
      debugPrint("SAVING Int === ${values}");
      _preference!.setInt(key, values);
    }
  }

  static int getInt({required String key}) {
    if (_preference != null) {
      return _preference!.getInt(key) ?? 0;
    } else {
      return 0;
    }
  }

  static setString({
    required String key,
    required String value,
  }) async {
    if (_preference != null) {
      debugPrint("SAVING String === $value");
      _preference!.setString(key, value);
    }
  }

  static String getString({required String key}) {
    if (_preference != null) {
      return _preference!.getString(key) ?? "";
    } else {
      return "";
    }
  }

  static Future<void> setBool({
    required String key,
    required bool value,
  }) async {
    if (_preference != null) {
      debugPrint("SAVING BOOL:$value");
      _preference!.setBool(key, value);
    }
  }

  static bool getBool({required String key}) {
    if (_preference != null) {
      return _preference!.getBool(key) ?? false;
    }
    return false;
  }

  static Future<void> setDouble({
    required String key,
    required double value,
  }) async {
    if (_preference != null) {
      debugPrint("SAVING DOUBLE:$value");
      _preference!.setDouble(key, value);
    }
  }

  static double getDouble({required String key}) {
    if (_preference != null) {
      return _preference!.getDouble(key) ?? 0.0;
    }
    return 0.0;
  }
}
